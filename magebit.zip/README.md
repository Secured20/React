# React Native Web example

Node.js, React Native, three.js

## How to use

```bash
npx create-next-app --example with-react-native-web with-react-native-web-app
```

```bash
yarn create next-app --example with-react-native-web with-react-native-web-app
```

```bash
pnpm create next-app --example with-react-native-web with-react-native-web-app
```

# Setup Project

npm install

npm run build

npm start