import { StyleSheet, Text, View } from "react-native";
import Image from 'next/image';
import Link from 'next/link'
import {Button, ButtonGroup} from "@nextui-org/react";
import img from '../images/world.jpg';

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    flexGrow: 1,
    justifyContent: "center",
  },
  link: {
    color: "blue",
  },
  textContainer: {
    alignItems: "center",
    marginTop: 16,
  },
  text: {
    alignItems: "center",
    fontSize: 24,
    marginBottom: 24,
  }
});
 
export default function App(props) {
  return (
    <View style={styles.container}>
      <Text accessibilityRole="header" style={styles.text}>
        Welcome to space adventure
      </Text>
      <Image
      src={img}
      width={500}
      height={500}
      alt="Alt is important for seo"
    />
    <div className="flex flex-wrap gap-4 items-center">
    <Link style={styles.link} href="/alternate" replace>
      <Button color="primary" variant="shadow">
        Start
      </Button>  
    </Link>
    </div>
      <View style={styles.textContainer}>
        <Text accessibilityRole="header" aria-level="2" style={styles.text}>
          Please click start to continue.
        </Text>
      </View>
    </View>
  );
}
