# Setupad Category Tree
# To start project run following commands:
# npm run-script build
# npm start