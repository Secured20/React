export { default as add } from './add.svg';
export { default as remove } from './remove.svg';
export { default as edit } from './edit.svg';
export { default as confirm } from './confirm.svg';
export { default as logo } from './logo.svg';
export { default as cancel } from './cancel.svg';
export { default as trash } from './trash.svg';
